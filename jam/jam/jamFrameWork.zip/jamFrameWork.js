// this is an example framework that allows users to create native style applications using an more modular sytnax rather than using 
//this genius piece of work is copyrighted by jamie andrew fisher of soctland a sexy developer with a love for programming meoww ;)



// controls all the master values about objects such as how many children there is the children name yada yada yada 
// this is just the fumblings of a drunken fool lalalalalal
(function(){
	
var jamFrameWork = {};


//collecting information about how many active objects there is.
jamFrameWork.viewList = new Array();
jamFrameWork.labelList = new Array();
jamFrameWork.activeView = null;


//returns the window the framework
window.jamFrameWork = jamFrameWork;

 
})();

