
(function(){
	

	
	jamFrameWork.createView = function(args){
	
		 this.width = args.width;
		 this.height = args.height;
	
		 if(this.id === undefined){
			this.id = "view" + jamFrameWork.viewList.length;
		 }
		
	
		//passes all the arguments required to build the div
		this.build = function(args){
	 		var id = args.id;
	 		var hw = "height:" + args.height + "px" + ";width:" + args.width + "px";
			document.write('<div style="'+hw+'" id="'+id+'"> </div>');
			
		 }({
			 height:this.height,
			 width:this.width,
			 id:this.id
		 });
		 
		 
		  // adds objects into the view. define these methods after the build execution
		 this.add = function(Widget){
		 $("#" + this.id).append(Widget.Build);
	
		 };
		 
		
	 
	
	 	 //css method allows you to assign as many css class elements as possible. define methods after build execution
		 this.css = function(){
		 	
			 for (var i=0; i < arguments.length; i++) {
			 	
			 $("#" + this.id).addClass(arguments[i]);	
				jamFrameWork.viewList.push(this.id);	
			 };
			   
		 }
		 
		 
		 
	    	
	};


window.jamFrameWork = jamFrameWork;


})();
